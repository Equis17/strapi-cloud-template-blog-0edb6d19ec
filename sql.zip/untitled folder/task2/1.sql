
create table staff
(
    sid   integer not null
        constraint staff_pk
            primary key,
    fname text,
    lname text,
    state text,
    store text
);

alter table staff
    owner to postgres;

create table product
(
    pid       integer not null
        constraint product_pk
            primary key,
    product   text,
    brand     text,
    unit_cost integer
);

alter table product
    owner to postgres;

create table time_period
(
    date     text,
    month    integer,
    quarter  integer,
    year     integer,
    quantity integer,
    price    double precision,
    tid      integer not null
        constraint time_period_pk
            primary key,
    sid      integer
        constraint time_period_staff_sid_fk
            references staff,
    pid      integer
        constraint time_period_product_pid_fk
            references product
);

alter table time_period
    owner to postgres;

create table sales
(
    sid       integer,
    pid       integer,
    date      text,
    unit_cost double precision,
    quantity  integer,
    price     double precision,
    tid       integer,
    fname     text,
    lname     text,
    state     text,
    store     text,
    product   text
);

alter table sales
    owner to postgres;

