SELECT COUNT(DISTINCT sid) AS unique_staff_members
FROM staff;

SELECT COUNT(*) AS transactions_2022_qtr3
FROM time_period
WHERE time_period.year = 2022 AND time_period.quarter = 3;
