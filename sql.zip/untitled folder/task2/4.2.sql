CREATE VIEW Profits_View_2 AS
SELECT
    year,
    quarter,
    state,
    SUM(total_sales) AS total_revenue
FROM
    Sales_Time_Staff
GROUP BY
    year,
    quarter,
    state;

-- Query for the full years 2021 and 2022
SELECT
    year,
    SUM(CASE WHEN state = 'QLD' THEN total_revenue ELSE 0 END) AS QLD,
    SUM(CASE WHEN state = 'NSW' THEN total_revenue ELSE 0 END) AS NSW,
    SUM(CASE WHEN state = 'WA' THEN total_revenue ELSE 0 END) AS WA,
    SUM(CASE WHEN state = 'SA' THEN total_revenue ELSE 0 END) AS SA
FROM
    Profits_View_2
WHERE
    year IN (2021, 2022)
GROUP BY
    year
ORDER BY
    year;

-- Query for the first half of 2023
SELECT
    '2023 H1' AS period,
    SUM(CASE WHEN state = 'QLD' THEN total_revenue ELSE 0 END) AS QLD,
    SUM(CASE WHEN state = 'NSW' THEN total_revenue ELSE 0 END) AS NSW,
    SUM(CASE WHEN state = 'WA' THEN total_revenue ELSE 0 END) AS WA,
    SUM(CASE WHEN state = 'SA' THEN total_revenue ELSE 0 END) AS SA
FROM
    Profits_View_2
WHERE
    year = 2023 AND quarter IN (1, 2)
GROUP BY
    period;


-- 2021,2335836625.920055,2884759482.880047,2337139159.0400295,2290467199.999967
-- 2022,2312367938.560005,2885828238.0801635,2390391902.7199984,2271195383.0400414
-- 2023 H1,468680292.4800105,591555905.279994,478394211.20000005,460327560.319993