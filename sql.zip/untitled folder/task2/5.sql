-----1

CREATE MATERIALIZED VIEW Sales_Product_Staff AS
SELECT
    s.sid,
    s.fname,
    s.lname,
    s.store,
    p.pid,
    p.product,
    p.brand,
    SUM(s.quantity) AS total_quantity,
    SUM(s.price) AS total_sales,
    SUM((s.price - s.unit_cost) * s.quantity) AS gross_income
FROM
    sales s
JOIN
    product p ON s.pid = p.pid
GROUP BY CUBE (
    s.sid,
    s.fname,
    s.lname,
    s.store,
    p.pid,
    p.product,
    p.brand
);


--------a
CREATE VIEW Top_3_Stores AS
SELECT
    store,
    SUM(gross_income) AS total_gross_income
FROM
    Sales_Product_Staff
WHERE store IS NOT NULL
GROUP BY
    store
ORDER BY
    total_gross_income DESC
LIMIT 3;

SELECT * FROM Top_3_Stores;


--------b
CREATE VIEW Most_Profitable_Item_Per_Store AS
WITH Store_Profit AS (
    SELECT
        store,
        product,
        SUM(gross_income) AS product_gross_income,
        ROW_NUMBER() OVER (PARTITION BY store ORDER BY SUM(gross_income) DESC) AS rn
    FROM
        Sales_Product_Staff
    WHERE store IS NOT NULL AND product IS NOT NULL
    GROUP BY
        store, product
)

SELECT
    store,
    product,
    product_gross_income
FROM
    Store_Profit
WHERE
    rn = 1;

SELECT * FROM Most_Profitable_Item_Per_Store;
