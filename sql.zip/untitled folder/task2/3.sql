CREATE MATERIALIZED VIEW Sales_Time_Staff AS
SELECT
    s.sid,
    s.fname,
    s.lname,
    s.state,
    s.store,
    tp.year,
    tp.quarter,
    tp.month,
    tp.date,
    SUM(s.quantity) AS total_quantity,
    SUM(s.price) AS total_sales,
    AVG(s.unit_cost) AS avg_unit_cost
FROM
    sales s
JOIN
    time_period tp ON s.tid = tp.tid
GROUP BY CUBE (
    s.sid,
    s.fname,
    s.lname,
    s.state,
    s.store,
    tp.year,
    tp.quarter,
    tp.month,
    tp.date
);